# VT.ENERGY

```
/*==========================LICENSE NOTICE==========================*/
/*
 * Description: AI/ML framework for Energy Intelligence Applications.
 * Identifier: VT
 * Type of software: Application.
 * License: MIT License. Refer to LICENSE file of the software package.
 * Company: Vidcentum Technologies Pvt Ltd, India (CIN: U72200TG2009PTC063723).
 * Copyright (c) 2024.
 * Email: support@vidcentum.com
 * Website: https://vidcentum.com
 * Address: Plot No. 1-62/20, Kavuri Hills, 
 *          Hyderabad - 500081, Telangana, India.
*/
/*========================END LICENSE NOTICE========================*/
```

# WARNING:
## VT.ENERGY is NOT fully available for self-hosting. We are moving our internal development to open source repository. We will announce a formal release when it is ready.

### We welcome contributors. Email to opensource@vt.energy

