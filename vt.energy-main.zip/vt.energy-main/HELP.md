# GitHub

### Create your public-private keys as described in the document below.
```
https://docs.github.com/en/authentication/connecting-to-github-with-ssh/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent
```

### Using SSH to clone and manage the development
```
https://docs.github.com/en/get-started/getting-started-with-git/about-remote-repositories#cloning-with-https-urls

https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/githubs-ssh-key-fingerprints
```

### Use passphrase in SSH keys

```
https://docs.github.com/en/authentication/connecting-to-github-with-ssh/about-ssh

```